# Live (GitHub-Flavored) Markdown Editor

[Use it here](http://saturngod.github.io/markdown-editor)

Forked from [jbt](https://github.com/jbt/markdown-editor)

Feel free to take the code and copy it and modify it and use it however you like. (If you really want a licence, see [WTFPL](http://www.wtfpl.net/txt/copying/))
